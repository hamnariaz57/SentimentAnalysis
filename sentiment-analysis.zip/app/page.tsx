"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { analyzeSentiment } from "@/lib/sentiment-analyzer"
import type { SentimentResult } from "@/lib/types"
import SentimentVisualizer from "@/components/sentiment-visualizer"
import SentimentHistory from "@/components/sentiment-history"

export default function Home() {
  const [text, setText] = useState<string>("")
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false)
  const [result, setResult] = useState<SentimentResult | null>(null)
  const [history, setHistory] = useState<Array<{ text: string; result: SentimentResult }>>([])

  const handleAnalyze = async () => {
    if (!text.trim()) return

    setIsAnalyzing(true)
    try {
      // Analyze the sentiment of the input text
      const sentimentResult = await analyzeSentiment(text)
      setResult(sentimentResult)

      // Add to history
      setHistory((prev) => [
        ...prev,
        {
          text,
          result: sentimentResult,
        },
      ])
    } catch (error) {
      console.error("Error analyzing sentiment:", error)
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <main className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold text-center mb-8">Sentiment Analysis</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Input Text</CardTitle>
            <CardDescription>Enter text to analyze its sentiment</CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Type or paste text here..."
              className="min-h-[200px]"
              value={text}
              onChange={(e) => setText(e.target.value)}
            />
            <Button className="mt-4 w-full" onClick={handleAnalyze} disabled={isAnalyzing || !text.trim()}>
              {isAnalyzing ? "Analyzing..." : "Analyze Sentiment"}
            </Button>
          </CardContent>
        </Card>

        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Analysis Result</CardTitle>
            <CardDescription>Sentiment visualization and score</CardDescription>
          </CardHeader>
          <CardContent>
            {result ? (
              <SentimentVisualizer result={result} />
            ) : (
              <div className="flex items-center justify-center h-[200px] text-gray-400">No analysis results yet</div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Analysis History</CardTitle>
          <CardDescription>Previous sentiment analysis results</CardDescription>
        </CardHeader>
        <CardContent>
          <SentimentHistory history={history} />
        </CardContent>
      </Card>
    </main>
  )
}
