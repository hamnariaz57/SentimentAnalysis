import type { SentimentResult } from "./types"
import { tokenize, stemWord } from "./text-processing"

// Import pre-trained sentiment lexicon
import { sentimentLexicon } from "./sentiment-lexicon"

/**
 * Analyzes the sentiment of the provided text
 * @param text - The text to analyze
 * @returns A promise that resolves to a SentimentResult object
 */
export async function analyzeSentiment(text: string): Promise<SentimentResult> {
  // Simulate processing time for demonstration purposes
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // Tokenize the input text
  const tokens = tokenize(text)

  // Calculate sentiment score
  let totalScore = 0
  let wordCount = 0
  const scoredWords: Record<string, number> = {}

  // Process each token
  tokens.forEach((token) => {
    const word = token.toLowerCase()
    const stem = stemWord(word)

    // Check if the word or its stem exists in our lexicon
    if (sentimentLexicon[word]) {
      totalScore += sentimentLexicon[word]
      scoredWords[word] = sentimentLexicon[word]
      wordCount++
    } else if (sentimentLexicon[stem]) {
      totalScore += sentimentLexicon[stem]
      scoredWords[word] = sentimentLexicon[stem]
      wordCount++
    }
  })

  // Calculate normalized score (-1 to 1)
  const normalizedScore = wordCount > 0 ? totalScore / Math.max(wordCount, 5) : 0

  // Clamp score between -1 and 1
  const clampedScore = Math.max(-1, Math.min(1, normalizedScore))

  // Calculate confidence based on the number of matched words
  const confidence = Math.min(1, wordCount / Math.max(10, tokens.length * 0.3))

  // Extract key phrases (words with the strongest sentiment)
  const keyPhrases = extractKeyPhrases(text, scoredWords)

  return {
    score: clampedScore,
    confidence,
    keyPhrases,
  }
}

/**
 * Extracts key phrases from the text based on sentiment scores
 * @param text - The original text
 * @param scoredWords - Record of words and their sentiment scores
 * @returns Array of key phrases
 */
function extractKeyPhrases(text: string, scoredWords: Record<string, number>): string[] {
  // Sort words by absolute sentiment value (strongest sentiment first)
  const sortedWords = Object.entries(scoredWords)
    .sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]))
    .slice(0, 10)
    .map(([word]) => word)

  // Find phrases containing these words (simple implementation)
  const phrases: string[] = []
  const sentences = text.split(/[.!?]+/).filter((s) => s.trim().length > 0)

  for (const word of sortedWords) {
    for (const sentence of sentences) {
      if (sentence.toLowerCase().includes(word.toLowerCase())) {
        // Extract a phrase around the word (simplified)
        const words = sentence.trim().split(/\s+/)
        const wordIndex = words.findIndex((w) => w.toLowerCase().includes(word.toLowerCase()))

        if (wordIndex >= 0) {
          const start = Math.max(0, wordIndex - 2)
          const end = Math.min(words.length, wordIndex + 3)
          const phrase = words.slice(start, end).join(" ")

          // Add if not already included
          if (!phrases.includes(phrase)) {
            phrases.push(phrase)
            if (phrases.length >= 5) break
          }
        }
      }
    }
    if (phrases.length >= 5) break
  }

  return phrases
}
