export interface SentimentResult {
  score: number // Range from -1 (negative) to 1 (positive)
  confidence: number // Range from 0 to 1
  keyPhrases: string[] // Important phrases that influenced the sentiment
}
