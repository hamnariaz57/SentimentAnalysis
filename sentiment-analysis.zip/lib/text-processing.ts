/**
 * Tokenizes text into individual words
 * @param text - The text to tokenize
 * @returns Array of tokens (words)
 */
export function tokenize(text: string): string[] {
  // Remove punctuation and split by whitespace
  return text
    .replace(/[^\w\s]/g, " ")
    .split(/\s+/)
    .filter((token) => token.length > 0)
}

/**
 * Simple stemming function to reduce words to their root form
 * This is a simplified version of stemming for demonstration
 * @param word - The word to stem
 * @returns The stemmed word
 */
export function stemWord(word: string): string {
  // Convert to lowercase
  let stem = word.toLowerCase()

  // Remove common suffixes (simplified)
  const suffixes = ["ing", "ed", "ly", "es", "s", "er", "est"]
  for (const suffix of suffixes) {
    if (stem.endsWith(suffix) && stem.length > suffix.length + 2) {
      stem = stem.slice(0, -suffix.length)
      break
    }
  }

  return stem
}
