import type { SentimentResult } from "@/lib/types"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { ThumbsUp, ThumbsDown, Minus, Smile, Frown, Meh } from "lucide-react"

interface SentimentVisualizerProps {
  result: SentimentResult
}

export default function SentimentVisualizer({ result }: SentimentVisualizerProps) {
  // Determine sentiment category and icon
  const getSentimentInfo = () => {
    if (result.score > 0.2) {
      return {
        label: "Positive",
        color: "bg-green-100 text-green-800",
        icon: <ThumbsUp className="h-5 w-5 mr-1" />,
        emoji: <Smile className="h-10 w-10 text-green-500" />,
      }
    } else if (result.score < -0.2) {
      return {
        label: "Negative",
        color: "bg-red-100 text-red-800",
        icon: <ThumbsDown className="h-5 w-5 mr-1" />,
        emoji: <Frown className="h-10 w-10 text-red-500" />,
      }
    } else {
      return {
        label: "Neutral",
        color: "bg-gray-100 text-gray-800",
        icon: <Minus className="h-5 w-5 mr-1" />,
        emoji: <Meh className="h-10 w-10 text-gray-500" />,
      }
    }
  }

  const sentimentInfo = getSentimentInfo()

  // Convert score to percentage for visualization (from -1...1 to 0...100)
  const scorePercentage = ((result.score + 1) / 2) * 100

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          {sentimentInfo.emoji}
          <div className="ml-3">
            <Badge className={sentimentInfo.color}>
              <span className="flex items-center">
                {sentimentInfo.icon}
                {sentimentInfo.label}
              </span>
            </Badge>
            <p className="text-sm mt-1">Confidence: {result.confidence.toFixed(2)}</p>
          </div>
        </div>
        <div className="text-2xl font-bold">{result.score.toFixed(2)}</div>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between text-xs">
          <span>Negative</span>
          <span>Neutral</span>
          <span>Positive</span>
        </div>
        <Progress value={scorePercentage} className="h-2" />
      </div>

      <div className="mt-4 p-4 bg-gray-50 rounded-md">
        <h4 className="font-medium mb-2">Key Phrases:</h4>
        <ul className="list-disc pl-5 space-y-1">
          {result.keyPhrases.map((phrase, index) => (
            <li key={index} className="text-sm">
              {phrase}
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
