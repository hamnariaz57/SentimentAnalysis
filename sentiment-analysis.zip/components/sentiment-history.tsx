import type { SentimentResult } from "@/lib/types"
import { ThumbsUp, ThumbsDown, Minus } from "lucide-react"

interface SentimentHistoryProps {
  history: Array<{ text: string; result: SentimentResult }>
}

export default function SentimentHistory({ history }: SentimentHistoryProps) {
  if (history.length === 0) {
    return <div className="text-center py-8 text-gray-500">No analysis history yet</div>
  }

  const getSentimentIcon = (score: number) => {
    if (score > 0.2) return <ThumbsUp className="h-4 w-4 text-green-500" />
    if (score < -0.2) return <ThumbsDown className="h-4 w-4 text-red-500" />
    return <Minus className="h-4 w-4 text-gray-500" />
  }

  return (
    <div className="space-y-4">
      {history.map((item, index) => (
        <div key={index} className="border rounded-md p-4">
          <div className="flex justify-between items-start mb-2">
            <div className="font-medium truncate max-w-[80%]">
              {item.text.length > 100 ? `${item.text.substring(0, 100)}...` : item.text}
            </div>
            <div className="flex items-center">
              {getSentimentIcon(item.result.score)}
              <span className="ml-1 text-sm font-medium">{item.result.score.toFixed(2)}</span>
            </div>
          </div>
          <div className="text-sm text-gray-500">
            Key phrases: {item.result.keyPhrases.slice(0, 2).join(", ")}
            {item.result.keyPhrases.length > 2 ? "..." : ""}
          </div>
        </div>
      ))}
    </div>
  )
}
